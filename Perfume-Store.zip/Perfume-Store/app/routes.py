from flask import Blueprint, request, jsonify
from app.models import Perfume  # Exemplo de importação de modelo

# Cria um Blueprint para as rotas
main_routes = Blueprint('main_routes', __name__)

@main_routes.route('/add_perfume', methods=['POST'])
def add_perfume():
    data = request.json
    # Lógica para adicionar um perfume ao banco de dados
    return jsonify({"message": "Perfume adicionado com sucesso!"}), 201

@main_routes.route('/perfumes', methods=['GET'])
def list_perfumes():
    # Lógica para listar todos os perfumes
    return jsonify({"perfumes": []}), 200