from app import db

class Perfume(db.Model):
    """
    Modelo para representar um perfume.
    """
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    brand = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False, default=0.0)

    def __repr__(self):
        """
        Retorna uma representação legível do objeto Perfume.
        
        Returns:
            str: Representação do perfume.
        """
        return f"Perfume('{self.name}', '{self.brand}', '{self.price}')"

    def to_dict(self):
        """
        Converte o objeto Perfume para um dicionário.
        
        Returns:
            dict: Dicionário com os dados do perfume.
        """
        return {
            "id": self.id,
            "name": self.name,
            "brand": self.brand,
            "price": self.price
        }