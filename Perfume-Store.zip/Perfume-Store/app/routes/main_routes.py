# Imports de bibliotecas de terceiros
from flask import Blueprint, jsonify, request, abort
from sqlalchemy.exc import SQLAlchemyError

# Imports locais
from app.models import Perfume  # Exemplo de modelo
from app import db

# Cria o blueprint para as rotas principais
bp = Blueprint('main', __name__)

# Função auxiliar para validar dados do perfume
def validate_perfume_data(data):
    """
    Valida os dados do perfume.
    
    Args:
        data (dict): Dados do perfume.
    
    Returns:
        tuple: (bool, str) onde o bool indica se os dados são válidos e a str contém a mensagem de erro.
    """
    if not data:
        return False, "Nenhum dado fornecido"
    if not data.get('name'):
        return False, "Nome é obrigatório"
    if not data.get('brand'):
        return False, "Marca é obrigatória"
    if 'price' in data and not isinstance(data['price'], (int, float)):
        return False, "Preço deve ser um número"
    return True, ""

# Rota para a página inicial
@bp.route('/')
def index():
    """
    Rota para a página inicial.
    
    Returns:
        str: Mensagem de boas-vindas.
    """
    return "Bem-vindo à Perfume Store!"

# Rota para listar todos os perfumes
@bp.route('/perfumes', methods=['GET'])
def list_perfumes():
    """
    Rota para listar todos os perfumes.
    
    Returns:
        JSON: Lista de perfumes.
    """
    perfumes = Perfume.query.all()
    return jsonify([perfume.to_dict() for perfume in perfumes])

# Rota para adicionar um novo perfume
@bp.route('/perfumes', methods=['POST'])
def add_perfume():
    """
    Rota para adicionar um novo perfume.
    
    Returns:
        JSON: Perfume adicionado.
    """
    data = request.get_json()
    
    # Validação dos dados
    is_valid, error_message = validate_perfume_data(data)
    if not is_valid:
        return jsonify({"error": error_message}), 400
    
    # Cria um novo perfume
    perfume = Perfume(
        name=data['name'],
        brand=data['brand'],
        price=data.get('price', 0.0)  # Preço é opcional
    )
    
    try:
        # Adiciona ao banco de dados
        db.session.add(perfume)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
    return jsonify(perfume.to_dict()), 201

# Rota para obter detalhes de um perfume específico
@bp.route('/perfumes/<int:perfume_id>', methods=['GET'])
def get_perfume(perfume_id):
    """
    Rota para obter detalhes de um perfume específico.
    
    Args:
        perfume_id (int): ID do perfume.
    
    Returns:
        JSON: Detalhes do perfume.
    """
    perfume = Perfume.query.get_or_404(perfume_id)
    return jsonify(perfume.to_dict())

# Rota para atualizar um perfume
@bp.route('/perfumes/<int:perfume_id>', methods=['PUT'])
def update_perfume(perfume_id):
    """
    Rota para atualizar um perfume.
    
    Args:
        perfume_id (int): ID do perfume.
    
    Returns:
        JSON: Perfume atualizado.
    """
    perfume = Perfume.query.get_or_404(perfume_id)
    data = request.get_json()
    
    # Validação dos dados
    is_valid, error_message = validate_perfume_data(data)
    if not is_valid:
        return jsonify({"error": error_message}), 400
    
    # Atualiza os campos
    if 'name' in data:
        perfume.name = data['name']
    if 'brand' in data:
        perfume.brand = data['brand']
    if 'price' in data:
        perfume.price = data['price']
    
    try:
        # Salva as alterações
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
    return jsonify(perfume.to_dict())

# Rota para excluir um perfume
@bp.route('/perfumes/<int:perfume_id>', methods=['DELETE'])
def delete_perfume(perfume_id):
    """
    Rota para excluir um perfume.
    
    Args:
        perfume_id (int): ID do perfume.
    
    Returns:
        JSON: Mensagem de sucesso.
    """
    perfume = Perfume.query.get_or_404(perfume_id)
    
    try:
        # Remove o perfume
        db.session.delete(perfume)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
    return jsonify({"message": "Perfume excluído com sucesso"}), 200