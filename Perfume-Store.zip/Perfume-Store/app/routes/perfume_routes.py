# app/routes/perfume_routes.py
from flask import Blueprint, jsonify
from app.models.perfume import Perfume

perfume_bp = Blueprint('perfume', __name__)

@perfume_bp.route('/perfumes', methods=['GET'])
def list_perfumes():
    perfumes = Perfume.query.all()
    return jsonify([{
        'id': perfume.id,
        'name': perfume.name,
        'brand': perfume.brand,
        'price': perfume.price,
        'stock': perfume.stock
    } for perfume in perfumes])