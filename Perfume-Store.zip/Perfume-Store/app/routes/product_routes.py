# app/routes/product_routes.py
from flask import Blueprint, jsonify
from app.models.product import Product

product_bp = Blueprint('product', __name__)

@product_bp.route('/products', methods=['GET'])
def get_products():
    products = Product.query.all()
    return jsonify([product.name for product in products])