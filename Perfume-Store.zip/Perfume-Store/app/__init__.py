# app/__init__.py

# Imports da biblioteca padrão
import os

# Imports de bibliotecas de terceiros
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

# Imports locais
from .config import Config

# Inicializa as extensões
db = SQLAlchemy()
migrate = Migrate()

def create_app(config_class=Config):
    """
    Factory function para criar e configurar a aplicação Flask.

    Args:
        config_class: Classe de configuração (padrão: Config).

    Returns:
        Flask: Instância da aplicação Flask.
    """
    # Cria a instância do Flask
    app = Flask(__name__)

    # Carrega as configurações da classe Config
    app.config.from_object(config_class)

    # Configurações específicas do SQLAlchemy
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URI', 'sqlite:///perfumes.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Inicializa as extensões com o app
    db.init_app(app)
    migrate.init_app(app, db)

    # Registra as rotas
    register_blueprints(app)

    # Configura o contexto da aplicação
    with app.app_context():
        # Cria as tabelas do banco de dados, se necessário
        db.create_all()

    return app

def register_blueprints(app):
    """
    Registra os blueprints (rotas) na aplicação Flask.

    Args:
        app (Flask): Instância da aplicação Flask.
    """
    from app.routes import main_routes  # Importação local para evitar dependências circulares
    app.register_blueprint(main_routes.bp)

# Cria a aplicação
app = create_app()