# app/services/perfume_service.py
from app.models.perfume import Perfume

def get_perfume_by_id(perfume_id):
    return Perfume.query.get(perfume_id)

def update_stock(perfume_id, quantity):
    perfume = get_perfume_by_id(perfume_id)
    if perfume and perfume.stock >= quantity:
        perfume.stock -= quantity
        return True
    return False