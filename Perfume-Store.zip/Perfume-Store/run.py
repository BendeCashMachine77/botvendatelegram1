# run.py
import sys
from pathlib import Path
import threading

# Adiciona o diretório raiz ao sys.path
sys.path.append(str(Path(__file__).parent))

from app import create_app
from bot import start_bot

# Cria a aplicação Flask
app = create_app()

# Função para iniciar o bot do Telegram em uma thread separada
def run_bot():
    start_bot()

if __name__ == "__main__":
    # Inicia o bot em uma thread separada
    bot_thread = threading.Thread(target=run_bot)
    bot_thread.start()

    # Inicia a aplicação Flask
    app.run(debug=True)