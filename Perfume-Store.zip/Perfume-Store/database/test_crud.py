# test_crud.py
from crud import criar_usuario, criar_perfume, listar_usuarios, buscar_usuario_por_email, atualizar_usuario, deletar_usuario

# Criar um usuário
usuario = criar_usuario(nome="Denise", email="denise@email.com", senha="12345678")
print(f"Usuário criado: {usuario.nome} ({usuario.email})")

# Criar um perfume
perfume = criar_perfume(titulo="Chanel n°5", qtde_pedidos=10, cliente_id=usuario.id)
print(f"Perfume criado: {perfume.titulo}")

# Listar todos os usuários
print("\nLista de usuários:")
for usuario in listar_usuarios():
    print(f"{usuario.id}: {usuario.nome} ({usuario.email})")

# Buscar usuário por email
usuario_denise = buscar_usuario_por_email("denise@email.com")
print(f"\nUsuário encontrado: {usuario_denise.nome}")

# Atualizar usuário
usuario_atualizado = atualizar_usuario(usuario.id, novo_nome="Denise Silva")
print(f"\nUsuário atualizado: {usuario_atualizado.nome}")

# Deletar usuário
deletar_usuario(usuario.id)
print("\nUsuário deletado.")