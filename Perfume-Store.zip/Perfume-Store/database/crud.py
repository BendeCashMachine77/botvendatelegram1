# crud.py
from models import session, Usuario, Perfume

# C - Create
def criar_usuario(nome, email, senha, ativo=True):
    usuario = Usuario(nome=nome, email=email, senha=senha, ativo=ativo)
    session.add(usuario)
    session.commit()
    return usuario

def criar_perfume(titulo, qtde_pedidos, cliente_id):
    perfume = Perfume(titulo=titulo, qtde_pedidos=qtde_pedidos, cliente_id=cliente_id)
    session.add(perfume)
    session.commit()
    return perfume

# R - Read
def listar_usuarios():
    return session.query(Usuario).all()

def buscar_usuario_por_email(email):
    return session.query(Usuario).filter_by(email=email).first()

# U - Update
def atualizar_usuario(id, novo_nome=None, novo_email=None, novo_senha=None, novo_ativo=None):
    usuario = session.query(Usuario).get(id)
    if usuario:
        if novo_nome:
            usuario.nome = novo_nome
        if novo_email:
            usuario.email = novo_email
        if novo_senha:
            usuario.senha = novo_senha
        if novo_ativo is not None:
            usuario.ativo = novo_ativo
        session.commit()
    return usuario

# D - Delete
def deletar_usuario(id):
    usuario = session.query(Usuario).get(id)
    if usuario:
        session.delete(usuario)
        session.commit()
    return usuario