# models.py
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, ForeignKey
from sqlalchemy.orm import sessionmaker, declarative_base

# Configuração do banco de dados
db = create_engine("sqlite:///meubanco.db")
Session = sessionmaker(bind=db)
session = Session()

Base = declarative_base()

# Tabela de Usuários
class Usuario(Base):
    __tablename__ = 'usuarios'
    id = Column("id", Integer, primary_key=True, autoincrement=True)
    nome = Column("nome", String)
    email = Column("email", String, unique=True)
    senha = Column("senha", String)
    ativo = Column("ativo", Boolean, default=True)

    def __init__(self, nome, email, senha, ativo=True):
        self.nome = nome
        self.email = email
        self.senha = senha
        self.ativo = ativo

# Tabela de Perfumes
class Perfume(Base):
    __tablename__ = "perfumes"
    id = Column("id", Integer, primary_key=True, autoincrement=True)
    titulo = Column("titulo", String)
    qtde_pedidos = Column("qtde_pedidos", Integer)
    cliente_id = Column("cliente_id", ForeignKey("usuarios.id"))

    def __init__(self, titulo, qtde_pedidos, cliente_id):
        self.titulo = titulo
        self.qtde_pedidos = qtde_pedidos
        self.cliente_id = cliente_id

# Cria as tabelas no banco de dados
Base.metadata.create_all(bind=db)