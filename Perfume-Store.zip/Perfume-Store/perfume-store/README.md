# Perfume Store

Este é um projeto de uma loja de perfumes com um bot de vendas integrado.

## Como executar

1. Clone o repositório.
2. Configure o ambiente virtual:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt