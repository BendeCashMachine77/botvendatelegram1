# config.py
# config.py
import os

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'uma_chave_secreta_muito_segura')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///instance/perfume_store.db')
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', 'seu_toke7998393148:AAFRIqsMHv7wFGBmrpBOrC78I1Yi2wew-KI')
    SQLALCHEMY_TRACK_MODIFICATIONS = False