# tests/test_perfume_service.py
from app.services.perfume_service import get_perfume_by_id, update_stock
from app.models.perfume import Perfume

def test_get_perfume_by_id():
    perfume = Perfume(name="Chanel N°5", brand="Chanel", price=299.99, stock=10)
    db.session.add(perfume)
    db.session.commit()

    result = get_perfume_by_id(perfume.id)
    assert result.name == "Chanel N°5"