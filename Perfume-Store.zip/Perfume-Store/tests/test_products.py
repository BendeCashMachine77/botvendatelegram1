# tests/test_products.py
import unittest
from app.models.product import Product
from app import create_app, db

class ProductTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_product_creation(self):
        product = Product(name="Perfume X", price=99.99)
        db.session.add(product)
        db.session.commit()
        self.assertEqual(product.name, "Perfume X")