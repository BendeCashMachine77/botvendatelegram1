from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Olá! Bem-vindo à Perfume-Store. Use /list para ver os perfumes disponíveis.")

async def list_perfumes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    perfumes = [
        {"name": "Perfume 1", "price": 50.0},
        {"name": "Perfume 2", "price": 75.0},
    ]
    response = "Perfumes disponíveis:\n"
    for perfume in perfumes:
        response += f"{perfume['name']} - ${perfume['price']}\n"
    await update.message.reply_text(response)

app = ApplicationBuilder().token("7998393148:AAFRIqsMHv7wFGBmrpBOrC78I1Yi2wew-KI").build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("list", list_perfumes))

def start_bot():
    app.run_polling()