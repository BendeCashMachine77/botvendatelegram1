import os
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# Configurações do bot
TELEGRAM_BOT_TOKEN = os.getenv("7998393148:AAFRIqsMHv7wFGBmrpBOrC78I1Yi2wew-KI")

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Olá! Bem-vindo à Perfume Store. Use /perfumes para ver nossa lista de perfumes.")

def list_perfumes(update: Update, context: CallbackContext):
    update.message.reply_text("Aqui está a lista de perfumes disponíveis...")

def main():
    # Inicializa o bot
    updater = Updater(TELEGRAM_BOT_TOKEN)
    dispatcher = updater.dispatcher

    # Adiciona handlers
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("perfumes", list_perfumes))

    # Inicia o bot
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()