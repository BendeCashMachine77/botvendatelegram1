# bot/handlers/perfume_handler.py
from telegram import Update
from telegram.ext import CallbackContext
from app.services.perfume_service import get_perfume_by_id

def handle_perfume_selection(update: Update, context: CallbackContext):
    perfume_id = int(context.args[0])
    perfume = get_perfume_by_id(perfume_id)
    if perfume:
        update.message.reply_text(
            f"Você selecionou: {perfume.name}\n"
            f"Marca: {perfume.brand}\n"
            f"Preço: R${perfume.price:.2f}"
        )
    else:
        update.message.reply_text("Perfume não encontrado.")