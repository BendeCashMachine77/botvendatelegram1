# bot/commands/start.py
from telegram import Update
from telegram.ext import CallbackContext

def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "Bem-vindo à Perfume Store! Use /perfumes para ver nossa lista de perfumes."
    )