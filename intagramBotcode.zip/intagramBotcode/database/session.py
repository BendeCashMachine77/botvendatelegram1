from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Configuração do banco de dados
db = create_engine("sqlite:///meubanco.db")
Session = sessionmaker(bind=db)
session = Session()