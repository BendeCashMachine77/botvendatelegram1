from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Usuario(Base):
    __tablename__ = 'usuarios'
    id = Column("id", Integer, primary_key=True, autoincrement=True)
    nome = Column("nome", String)
    email = Column("email", String)
    senha = Column("senha", String)
    ativo = Column("ativo", Boolean)

    def __init__(self, nome, email, senha, ativo):
        self.nome = nome
        self.email = email
        self.senha = senha
        self.ativo = ativo


class Perfumes(Base):
    __tablename__ = "perfumes"
    id = Column("id", Integer, primary_key=True, autoincrement=True)
    titulo = Column("titulo", String)
    qtde_pedidos = Column("qtde_pedidos", Integer)
    cliente = Column("cliente", ForeignKey("usuarios.id"))

    def __init__(self, titulo, qtde_pedidos, cliente):
        self.titulo = titulo
        self.qtde_pedidos = qtde_pedidos
        self.cliente = cliente