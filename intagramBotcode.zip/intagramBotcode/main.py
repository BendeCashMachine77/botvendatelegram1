from database.session import db
from database.models import Base
from instagram.bot import monitorar_comentarios

# Cria as tabelas no banco de dados (se não existirem)
Base.metadata.create_all(bind=db)

# Inicia o monitoramento de comentários
monitorar_comentarios()