from instagrapi import Client
from time import sleep
from database.session import session
from database.models import Usuario

# Configuração do cliente do Instagram
cl = Client()
cl.login("SEU_USUARIO", "SUA_SENHA")

# ID da publicação que você quer monitorar
POST_ID = "ID_DA_PUBLICACAO"

def monitorar_comentarios():
    print("Monitorando comentários...")
    while True:
        # Pega os comentários mais recentes da publicação
        comentarios = cl.media_comments(POST_ID)
        
        for comentario in comentarios:
            texto = comentario.text.lower()  # Converte para minúsculas
            usuario = comentario.user.username  # Nome do usuário que comentou

            # Verifica se o comentário contém a palavra "quero"
            if "quero" in texto:
                print(f"Usuário {usuario} comentou 'quero'. Enviando DM...")
                
                # Envia uma mensagem no Direct Message
                mensagem = f"Oi, @{usuario}! Vi que você comentou 'quero'. Como posso ajudar?"
                cl.direct_send(mensagem, user_ids=[comentario.user.pk])
                
                # Salva o usuário no banco de dados (se ainda não existir)
                if not session.query(Usuario).filter_by(email=f"{usuario}@instagram.com").first():
                    novo_usuario = Usuario(
                        nome=usuario,
                        email=f"{usuario}@instagram.com",
                        senha="",  # Você pode gerar uma senha temporária ou deixar em branco
                        ativo=True
                    )
                    session.add(novo_usuario)
                    session.commit()
                
                # Marca o comentário como respondido (opcional)
                cl.media_comment_delete(POST_ID, comentario.pk)
        
        # Espera 60 segundos antes de verificar novamente
        sleep(60)